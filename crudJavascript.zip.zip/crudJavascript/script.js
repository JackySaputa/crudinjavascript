dataBarang = [];

function tampilBarang() {
  let list = document.querySelector(".list-barang");
  list.innerHTML = "";
  let no = 1;
  for (let i = 0; i < dataBarang.length; i++) {
    // let edit = document.createElement ('button');
    // edit.setAttribute('type', 'submit');
    // const newValue = document.createTextNode ('Edit');
    // pBaru.appendChild (newValue);
    var edit = `<a href='#' onclick='edit("${i}")'>Edit</a>`;
    var hapus = `<a href='#' onclick='hapus("${i}")'>Hapus</a>`;
    list.innerHTML += `<li>${no + i} ${dataBarang[i]} ${edit} ${hapus}</li>`;
  }
}

document.querySelector(".button").addEventListener("click", () => {
  alert("Data Berhasil Di Tambah");
  let input = document.querySelector(".barang").value;
  dataBarang.push(input);
  tampilBarang();
});

function edit(id) {
  var newBarang = prompt("Klik Oke Untuk Menyimpan", dataBarang[id]);
  dataBarang[id] = newBarang;
  tampilBarang();
}

function hapus(id) {
  dataBarang.splice(id, 1);
  tampilBarang();
  alert ('Data Berhasil Di Hapus');
}

// const edit = documen.querySelector('.edit');
// const del = documen.querySelector('.delete');
